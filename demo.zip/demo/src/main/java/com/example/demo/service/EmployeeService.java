package com.example.demo.service;

import com.example.demo.dto.ApiBaseResponse;
import com.example.demo.dto.EmployeeDto;

public interface EmployeeService {

	ApiBaseResponse getAllEmployeeList();

	ApiBaseResponse getListOfCompetencySalary(String salary);

	ApiBaseResponse updateEmployeeSalary(String place, String percentage);

	ApiBaseResponse saveInformation(EmployeeDto employeeDto);

}
