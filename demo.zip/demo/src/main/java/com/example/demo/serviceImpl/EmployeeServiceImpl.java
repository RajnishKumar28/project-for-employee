package com.example.demo.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.example.demo.dto.ApiBaseResponse;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.dto.EmployeeResponseDto;
import com.example.demo.dto.ResponseDto;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public ApiBaseResponse getAllEmployeeList() {
		ApiBaseResponse apiBaseResponse = new ApiBaseResponse();
		ResponseDto responseDto = new ResponseDto();
		try {
			Iterable<Employee> employeeList = employeeRepository.findAll();

			responseDto.setResponseCode(HttpStatus.FOUND.value());
			responseDto.setResponseDescription("data found");

			responseDto.setMessage("success");

			apiBaseResponse.setData(employeeList);

		} catch (Exception e) {
			responseDto.setExceptionCode(HttpStatus.NOT_FOUND.value());
			responseDto.setExceptionDescription("data not found");

			apiBaseResponse.setResponseDto(responseDto);
		}

		return apiBaseResponse;
	}

	@Override
	public ApiBaseResponse getListOfCompetencySalary(String compentency) {

		ApiBaseResponse apiBaseResponse = new ApiBaseResponse();
		ResponseDto responseDto = new ResponseDto();

		List<EmployeeResponseDto> listOfEmpSalary = new ArrayList<>();
		EmployeeResponseDto employeeResponseDto = new EmployeeResponseDto();

		try {

			List<Employee> listOfSalary = employeeRepository.findByCompetenceies(compentency);
			for (Employee emp : listOfSalary) {
				employeeResponseDto.setSalary(emp.getSalary());
				listOfEmpSalary.add(employeeResponseDto);
			}

			responseDto.setResponseCode(HttpStatus.FOUND.value());
			responseDto.setResponseDescription("data found");

			responseDto.setMessage("success");

			apiBaseResponse.setData(listOfEmpSalary);
		} catch (Exception e) {
			responseDto.setExceptionCode(HttpStatus.NOT_FOUND.value());
			responseDto.setExceptionDescription("data not found");

			apiBaseResponse.setResponseDto(responseDto);
		}
		return apiBaseResponse;
	}

	@Override
	public ApiBaseResponse updateEmployeeSalary(String place, String percentage) 
	{
		ApiBaseResponse apiBaseResponse = new ApiBaseResponse();
		ResponseDto responseDto = new ResponseDto();

		try {

			if (org.springframework.util.StringUtils.isEmpty(place)
					|| org.springframework.util.StringUtils.isEmpty(percentage)) {
				responseDto.setExceptionCode(HttpStatus.BAD_REQUEST.value());
				responseDto.setMessage("bad request");
				responseDto.setExceptionDescription("parameter should not be null");

				apiBaseResponse.setResponseDto(responseDto);
			}
			if (Long.parseLong(percentage) > 55) {
				responseDto.setExceptionCode(HttpStatus.BAD_REQUEST.value());
				responseDto.setMessage("bad request");
				responseDto.setExceptionDescription("percentage should be more than 55");

				apiBaseResponse.setResponseDto(responseDto);
			} else {
				Optional<Employee> empOptional = employeeRepository.findByPlace(place);

				if (empOptional.isPresent()) {
					Employee emp = empOptional.get();

					if (!emp.getPlace().equalsIgnoreCase(place)) {
						responseDto.setExceptionCode(HttpStatus.BAD_REQUEST.value());
						responseDto.setMessage("bad request");
						responseDto.setExceptionDescription("place  not matched ");

						apiBaseResponse.setResponseDto(responseDto);

					} else {
						Double increasedSalary = Double.parseDouble(emp.getSalary())
								+ Double.parseDouble(percentage) / 100;

						emp.setSalary(increasedSalary.toString());

						employeeRepository.save(emp);

						responseDto.setResponseCode(HttpStatus.OK.value());

						responseDto.setResponseDescription("record modified successfully");
						
						apiBaseResponse.setResponseDto(responseDto);
					}
				}
			}
		} catch (Exception e) {

			responseDto.setExceptionCode(HttpStatus.NOT_MODIFIED.value());
			responseDto.setMessage("record not modified");
			responseDto.setExceptionDescription("record not modified something error while recording data");
			apiBaseResponse.setResponseDto(responseDto);
		}
		return apiBaseResponse;
	}

	@Override
	public ApiBaseResponse saveInformation(EmployeeDto employeeDto) {

		ApiBaseResponse apiBaseResponse = new ApiBaseResponse();
		ResponseDto responseDto = new ResponseDto();

		try {
			Employee employee = new Employee();

			employee.setBusinessUnit(employeeDto.getBusinessUnit());
			employee.setCompetenceies(employeeDto.getCompetenceies());
			employee.setEmployeeName(employeeDto.getEmployeeName());
			employee.setPlace(employeeDto.getPlace());
			employee.setSalary(employeeDto.getSalary());
			employee.setSupervisorId(employeeDto.getSupervisorId());
			employee.setTitle(employeeDto.getTitle());

			employeeRepository.save(employee);

			responseDto.setResponseCode(HttpStatus.OK.value());
			responseDto.setResponseDescription("data saved successfully ");
			responseDto.setMessage("success");
			apiBaseResponse.setResponseDto(responseDto);

		} catch (Exception e) {
			responseDto.setExceptionCode(HttpStatus.NOT_FOUND.value());
			responseDto.setExceptionDescription("data not found");

			apiBaseResponse.setResponseDto(responseDto);
		}
		return apiBaseResponse;
	}

}
