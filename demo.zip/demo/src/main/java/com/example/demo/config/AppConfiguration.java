
package com.example.demo.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.SpringSessionContext;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;



/**
 * @Description:This class provides configuration for database
 * @author: Rizwan
 * @createdOn:29 Sep 2017
 * 
 */
@EnableWebMvc
@Configuration
@EnableTransactionManagement
@ConfigurationProperties(prefix = "spring.datasource")
public class AppConfiguration implements WebMvcConfigurer {

	@Autowired
	private Environment environment;

	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}

	@Bean
	public DataSource getDatasource() {

		DriverManagerDataSource dmdatasource = new DriverManagerDataSource();
		dmdatasource.setDriverClassName(
				environment.getRequiredProperty(ExampleDemoConstants.SPRING_DATASOURSE_DRIVERCLASSNAME));
		dmdatasource.setUrl(environment.getRequiredProperty(ExampleDemoConstants.SPRING_DATASOURSE_URL));
		dmdatasource.setUsername(environment.getRequiredProperty(ExampleDemoConstants.SPRING_DATASOURSE_USERNAME));
		dmdatasource.setPassword(environment.getRequiredProperty(ExampleDemoConstants.SPRING_DATASOURSE_PASS));
		return dmdatasource;
	}

	@Bean
	protected Properties hibenateConfig() {
		Properties hibernateProperties = new Properties();

		hibernateProperties.setProperty(ExampleDemoConstants.HIBERNATE_DIALECT,
				environment.getRequiredProperty(ExampleDemoConstants.HIBERNATE_DIALECT));
		hibernateProperties.setProperty(ExampleDemoConstants.HIBERNATE_SHOW_SQL,
				environment.getRequiredProperty(ExampleDemoConstants.HIBERNATE_SHOW_SQL));
		hibernateProperties.setProperty(ExampleDemoConstants.HIBERNATE_USE_SQL_COMMENTS,
				environment.getProperty(ExampleDemoConstants.HIBERNATE_USE_SQL_COMMENTS));
		hibernateProperties.setProperty(ExampleDemoConstants.HIBERNATE_FORMAT_SQL,
				environment.getProperty(ExampleDemoConstants.HIBERNATE_FORMAT_SQL));
		hibernateProperties.setProperty(ExampleDemoConstants.HIBERNATE_GENERATE_STATISTICS,
				environment.getProperty(ExampleDemoConstants.HIBERNATE_GENERATE_STATISTICS));
		hibernateProperties.setProperty(ExampleDemoConstants.JAVAX_PERSISTENCE_VALIDATION_MODE,
				environment.getProperty(ExampleDemoConstants.JAVAX_PERSISTENCE_VALIDATION_MODE));
		hibernateProperties.setProperty(ExampleDemoConstants.ORG_HIBERNATE_ENVERS_STORE_DATA_AT_DELETE,
				environment.getProperty(ExampleDemoConstants.ORG_HIBERNATE_ENVERS_STORE_DATA_AT_DELETE));
		hibernateProperties.setProperty(ExampleDemoConstants.ORG_HIBERNATE_ENVERS_GLOBAL_WITH_MODIFIED_FLAG,
				environment.getProperty(ExampleDemoConstants.ORG_HIBERNATE_ENVERS_GLOBAL_WITH_MODIFIED_FLAG));

		hibernateProperties.setProperty(ExampleDemoConstants.HIBERNATE_HBM2DDL_AUTO,
				environment.getRequiredProperty(ExampleDemoConstants.HIBERNATE_HBM2DDL_AUTO));

		hibernateProperties.setProperty(ExampleDemoConstants.HIBERNATE_CURRENT_SESSION_CONTEXT_CLASS,
				SpringSessionContext.class.getName());

		return hibernateProperties;
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();

		entityManagerFactoryBean.setDataSource(getDatasource());
		entityManagerFactoryBean.setJpaProperties(hibenateConfig());

		HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
		jpaVendorAdapter.setDatabase(Database.MYSQL);

		entityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);

		entityManagerFactoryBean.setPackagesToScan(ExampleDemoConstants.Example_DAO);
		return entityManagerFactoryBean;
	}

	@Override
	public void addResourceHandlers(final ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}

}