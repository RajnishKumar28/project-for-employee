package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EmployeeDetails")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "EmployeeId", unique = true, nullable = false)
	private Long employeeId;

	@Column(name = "EmployeeName")
	private String employeeName;

	@Column(name = "Title")
	private String title;

	@Column(name = "BusinessUnit")
	private String businessUnit;

	@Column(name = "Place")
	private String place;

	@Column(name = "SupervisorId")
	private long supervisorId;

	@Column(name = "Competenceies")
	private String competenceies;

	@Column(name = "Salary")
	private String salary;

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public long getSupervisorId() {
		return supervisorId;
	}

	public void setSupervisorId(long supervisorId) {
		this.supervisorId = supervisorId;
	}

	public String getCompetenceies() {
		return competenceies;
	}

	public void setCompetenceies(String competenceies) {
		this.competenceies = competenceies;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

}
