package com.example.demo.dto;

public class EmployeeRequestDto 
{
	private String compentency;

	public String getCompentency() {
		return compentency;
	}

	public void setCompentency(String compentency) {
		this.compentency = compentency;
	}

	
	
	

}
