package com.example.demo.controllerTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.controller.EmployeeController;
import com.example.demo.dto.ApiBaseResponse;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.dto.EmployeeRequestDto;
import com.example.demo.service.EmployeeService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@SuppressWarnings({ "unchecked", "unused" })
public class EmployeeControllerTest {
	@InjectMocks
	EmployeeController employeeController;

	private MockMvc mockMvc;

	@Mock
	EmployeeService employeeService;

	@Before
	public void setUp() {

		mockMvc = MockMvcBuilders.standaloneSetup(employeeController).build();
	}

	@Test
	public void getListOfAllEmployeeTest() throws Exception {

		ApiBaseResponse apiResponse2 = new ApiBaseResponse();

		String inputInJson = this.mapToJson(apiResponse2);

		String URI = "/api/employee/employeeList";

		Mockito.when(employeeService.getAllEmployeeList()).thenReturn(apiResponse2);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI).accept(MediaType.APPLICATION_JSON)
				.content(inputInJson).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();

		String outputInJson = response.getContentAsString();

		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}
	@Test
	public void getListOfCompetencySalaryTest() throws Exception {

		ApiBaseResponse apiResponse2 = new ApiBaseResponse();

		String inputInJson = this.mapToJson(apiResponse2);
		EmployeeRequestDto employeeRequestDto=new EmployeeRequestDto();
		employeeRequestDto.setCompentency("800.00");

		String URI = "/api/employee/competencySalary";

		Mockito.when(employeeService.getListOfCompetencySalary(employeeRequestDto.getCompentency())).thenReturn(apiResponse2);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(URI).accept(MediaType.APPLICATION_JSON)
				.content(inputInJson).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();

		String outputInJson = response.getContentAsString();

		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}
	@Test
	public void updateEmployeeSalaryTest() throws Exception {

		ApiBaseResponse apiResponse2 = new ApiBaseResponse();

		String inputInJson = this.mapToJson(apiResponse2);

		String URI = "/api/employee/place/{place}/salary/{percentage}";

		Mockito.when(employeeService.updateEmployeeSalary("Gurugram", "67")).thenReturn(apiResponse2);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.put(URI).accept(MediaType.APPLICATION_JSON)
				.content(inputInJson).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();

		String outputInJson = response.getContentAsString();

		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}
	@Test
	public void saveInformationTest() throws Exception {

		ApiBaseResponse apiResponse2 = new ApiBaseResponse();
		
		EmployeeDto employeeDto=new EmployeeDto();
		employeeDto.setEmployeeName("Rajnish kumar");
		employeeDto.setPlace("gurugram");
		employeeDto.setBusinessUnit("90");
		employeeDto.setCompetenceies("900.00");
		employeeDto.setSalary("980000.00");
		employeeDto.setSupervisorId(90l);
		employeeDto.setTitle("employee details");
		String inputInJson = this.mapToJson(apiResponse2);

		String URI = "/api/employee/saveEmployeeDetails";

		Mockito.when(employeeService.saveInformation(employeeDto)).thenReturn(apiResponse2);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(URI).accept(MediaType.APPLICATION_JSON)
				.content(inputInJson).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();

		String outputInJson = response.getContentAsString();

		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}



	private String mapToJson(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();

		return objectMapper.writeValueAsString(object);
	}

}
