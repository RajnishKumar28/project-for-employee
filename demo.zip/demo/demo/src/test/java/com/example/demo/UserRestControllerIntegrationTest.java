package com.example.demo;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kopitubruk.util.json.JSONUtil;
import org.mockito.Mockito;
import org.mockito.internal.verification.VerificationModeFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.controller.UserRestController;
import com.example.demo.model.CalonexUser;
import com.example.demo.service.UserService;

@RunWith(SpringRunner.class)
@WebMvcTest(UserRestController.class)
public class UserRestControllerIntegrationTest {
	@Autowired
	private MockMvc mvc;

	@MockBean
	private UserService service;
	
	 @Autowired
	    private TestEntityManager entityManager;
	 

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void whenPostEmployee_thenCreateEmployee() throws Exception {
		CalonexUser alex = new CalonexUser("alex");
		 entityManager.persist(alex);
	        entityManager.flush();
		when(service.save(Mockito.any())).thenReturn(alex);

		mvc.perform(post("/api/employees").contentType(MediaType.APPLICATION_JSON).content(JSONUtil.toJSON(alex)))
				.andExpect(status().isCreated()).andExpect(jsonPath("$.name", is("alex")));
		verify(service, VerificationModeFactory.times(1)).save(Mockito.any());
		reset(service);
	}

	@Test
	public void givenEmployees_whenGetEmployees_thenReturnJsonArray() throws Exception {
		CalonexUser alex = new CalonexUser("alex");
		CalonexUser john = new CalonexUser("john");
		CalonexUser bob = new CalonexUser("bob");
		
		 entityManager.persist(alex);
	        entityManager.flush();

		List<CalonexUser> allEmployees = Arrays.asList(alex, john, bob);

		when(service.getAllUsers()).thenReturn(allEmployees);

		mvc.perform(get("/api/employees").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(3))).andExpect(jsonPath("$[0].name", is(alex.getName())))
				.andExpect(jsonPath("$[1].name", is(john.getName())))
				.andExpect(jsonPath("$[2].name", is(bob.getName())));
		verify(service, VerificationModeFactory.times(1)).getAllUsers();
		reset(service);
	}

}
