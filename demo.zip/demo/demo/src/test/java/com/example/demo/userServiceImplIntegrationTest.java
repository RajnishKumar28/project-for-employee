package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.model.CalonexUser;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;
import com.example.demo.serviceImpl.UserServiceImpl;

@RunWith(SpringRunner.class)
public class userServiceImplIntegrationTest {

	@TestConfiguration
	static class userServiceImplTestContextConfiguration {

		@Bean
		public UserService userService() {
			return new UserServiceImpl();
		}
	}

	@Autowired
	private UserService userService;

	@MockBean
	private UserRepository userRepository;

	@Before
	public void setUp() {
		CalonexUser alex = new CalonexUser("alex");

		Mockito.when(userRepository.findByName(alex.getName())).thenReturn(alex);
	}

	@Test
	public void whenValidName_thenEmployeeShouldBeFound() {
		String name = "alex";
		CalonexUser found = userService.getUserByName(name);

		assertThat(found.getName()).isEqualTo(name);
	}
}
