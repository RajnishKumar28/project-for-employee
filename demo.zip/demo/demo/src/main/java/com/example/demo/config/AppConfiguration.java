
package com.example.demo.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.SpringSessionContext;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @Description:This class provides configuration for database
 * @author: Rizwan
 * @createdOn:29 Sep 2017
 * 
 */
@EnableWebMvc
@Configuration
@EnableTransactionManagement
@ConfigurationProperties(prefix = "spring.datasource")
public class AppConfiguration implements WebMvcConfigurer {

	@Autowired
	private Environment environment;

	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}

	@Bean
	public DataSource getDatasource() {

		DriverManagerDataSource dmdatasource = new DriverManagerDataSource();
		dmdatasource.setDriverClassName(
				environment.getRequiredProperty(CalonexConstants.SPRING_DATASOURSE_DRIVERCLASSNAME));
		dmdatasource.setUrl(environment.getRequiredProperty(CalonexConstants.SPRING_DATASOURSE_URL));
		dmdatasource.setUsername(environment.getRequiredProperty(CalonexConstants.SPRING_DATASOURSE_USERNAME));
		dmdatasource.setPassword(environment.getRequiredProperty(CalonexConstants.SPRING_DATASOURSE_PASS));
		return dmdatasource;
	}

	@Bean
	protected Properties hibenateConfig() {
		Properties hibernateProperties = new Properties();

		hibernateProperties.setProperty(CalonexConstants.HIBERNATE_DIALECT,
				environment.getRequiredProperty(CalonexConstants.HIBERNATE_DIALECT));
		hibernateProperties.setProperty(CalonexConstants.HIBERNATE_SHOW_SQL,
				environment.getRequiredProperty(CalonexConstants.HIBERNATE_SHOW_SQL));
		hibernateProperties.setProperty(CalonexConstants.HIBERNATE_USE_SQL_COMMENTS,
				environment.getProperty(CalonexConstants.HIBERNATE_USE_SQL_COMMENTS));
		hibernateProperties.setProperty(CalonexConstants.HIBERNATE_FORMAT_SQL,
				environment.getProperty(CalonexConstants.HIBERNATE_FORMAT_SQL));
		hibernateProperties.setProperty(CalonexConstants.HIBERNATE_GENERATE_STATISTICS,
				environment.getProperty(CalonexConstants.HIBERNATE_GENERATE_STATISTICS));
		hibernateProperties.setProperty(CalonexConstants.JAVAX_PERSISTENCE_VALIDATION_MODE,
				environment.getProperty(CalonexConstants.JAVAX_PERSISTENCE_VALIDATION_MODE));
		hibernateProperties.setProperty(CalonexConstants.ORG_HIBERNATE_ENVERS_STORE_DATA_AT_DELETE,
				environment.getProperty(CalonexConstants.ORG_HIBERNATE_ENVERS_STORE_DATA_AT_DELETE));
		hibernateProperties.setProperty(CalonexConstants.ORG_HIBERNATE_ENVERS_GLOBAL_WITH_MODIFIED_FLAG,
				environment.getProperty(CalonexConstants.ORG_HIBERNATE_ENVERS_GLOBAL_WITH_MODIFIED_FLAG));

		hibernateProperties.setProperty(CalonexConstants.HIBERNATE_HBM2DDL_AUTO,
				environment.getRequiredProperty(CalonexConstants.HIBERNATE_HBM2DDL_AUTO));

		hibernateProperties.setProperty(CalonexConstants.HIBERNATE_CURRENT_SESSION_CONTEXT_CLASS,
				SpringSessionContext.class.getName());

		return hibernateProperties;
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();

		entityManagerFactoryBean.setDataSource(getDatasource());
		entityManagerFactoryBean.setJpaProperties(hibenateConfig());

		HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
		jpaVendorAdapter.setDatabase(Database.MYSQL);

		entityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);

		entityManagerFactoryBean.setPackagesToScan(CalonexConstants.CALONEX_DAO);
		return entityManagerFactoryBean;
	}

	/*
	 * comment below method (addInterceptors) To bypass ADFS
	 */

	/*
	 * @Bean public HibernateJpaSessionFactoryBean sessionFactory() { return new
	 * HibernateJpaSessionFactoryBean(); }
	 */

	@Override
	public void addResourceHandlers(final ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}

}