package com.example.demo.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.example.demo.model.CalonexUser;

@Service
public interface UserService 
{

	CalonexUser getUserByName(String name);

	
     Object save(CalonexUser user);

	List<CalonexUser> getAllUsers();

}
