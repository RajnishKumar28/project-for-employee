package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.CalonexUser;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/api")
@EnableAutoConfiguration
public class UserRestController {

	@Autowired
	private UserService userService;

	@PostMapping("/employees")
	public Object save(CalonexUser employee) {
		return userService.save(employee);
	}

	@GetMapping("/employees")
	public List<CalonexUser> getAllEmployees() {
		return userService.getAllUsers();
	}

}
