package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.CalonexUser;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	public CalonexUser getUserByName(String name) {
		return userRepository.findByName(name);
	}

	@Override
	public List<CalonexUser> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	public Object save(CalonexUser user) {

		return userRepository.save(user);
	}

}